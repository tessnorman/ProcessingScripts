SUBJECT:    	osrmtime: Calculate Travel Time and Distance with OpenStreetMap Data Using the Open Source Routing Machine (OSRM)

AUTHOR(S):  	Stephan
		Huber

		Christoph
		Rust

SUPPORT:    	stephan.huber@wiwi.uni-regensburg.de
		christoph.rust@stud.uni-regensburg.de

HELP:       After installation, type
            . help osrmtime

FILES:

osrmtime.ado
osrmprepare.ado
osrminterface.ado
osrmtime.sthlp
